# Velocity Crash

Velocity Crash is a single-page browser game built with React, Vite, and Tailwind CSS. All progress (coins, scores, settings, unlocks, language) is stored locally in the browser via `localStorage` — there is no database, no backend, and no external services.

## Local development

```bash
npm install
npm run dev
```

## Production build

```bash
npm run build
```

The build outputs a single static `dist/index.html` (plus `dist/favicon.svg` and `dist/404.html`).

## Deploy to Vercel

1. Push this repository to GitHub. The `package.json`, `vercel.json`, `vite.config.ts`, `tsconfig.json`, `index.html`, `src/`, and `public/` folders all sit directly at the repository root (flat structure).
2. In Vercel, click **Add New → Project** and import the GitHub repository.
3. Vercel auto-detects **Vite** as the framework. If it does not, set the Framework Preset to `Vite` manually.
4. Keep the defaults:
   - Build Command: `npm run build`
   - Output Directory: `dist`
   - Install Command: `npm install`
5. Click **Deploy**. No environment variables are required.

`vercel.json` includes the SPA rewrite to `/index.html`, so client-side routes and refreshes resolve without a 404.

## Notes

- No database, no `DATABASE_URL`, no Prisma, no `@prisma/client`.
- All data is persisted in `localStorage` under the `velocity-crash-*` keys.
- The production build runs cleanly with the dependency set in `package.json` (no ESLint or TypeScript-ESLint version conflicts).
